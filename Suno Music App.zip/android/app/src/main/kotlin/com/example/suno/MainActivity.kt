package com.example.suno

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
